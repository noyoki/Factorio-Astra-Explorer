
data.raw.technology["space-platform"].prerequisites = {}
data.raw.technology["space-platform"].enabled = true;

table.insert(data.raw["technology"]["space-platform"].effects, {type = "unlock-recipe", recipe = "space-platform-foundation"})